# Car Detection > 2024-02-15 11:23am
https://universe.roboflow.com/test01-vxotp/car-detection-3fcmk

Provided by a Roboflow user
License: CC BY 4.0

